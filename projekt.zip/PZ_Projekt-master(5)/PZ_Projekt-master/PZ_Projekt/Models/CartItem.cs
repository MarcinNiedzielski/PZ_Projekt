﻿namespace PZ_Projekt.Models
{
    public class CartItem
    {
        public Item Item { get; set; }
        public int Quantity { get; set; }
    }
}
